from django.urls import path,include
from . import views
urlpatterns = [
    path('model1',views.Welcome)
]
