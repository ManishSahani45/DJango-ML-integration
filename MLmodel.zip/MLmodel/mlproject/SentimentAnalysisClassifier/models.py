from django.db import models
class db(models.Model):
    text=models.CharField(max_length=500)
    result=models.CharField(max_length=100)

