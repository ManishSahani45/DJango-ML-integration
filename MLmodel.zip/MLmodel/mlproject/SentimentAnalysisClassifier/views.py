from operator import neg
from django.shortcuts import render
from joblib import load
from nltk.sentiment import SentimentIntensityAnalyzer
from regex import P
sia=SentimentIntensityAnalyzer()
from . models import db


#model = load('./savedmodels/Twitter_SIC_Logistic_R.joblib')

def predictor(request):
    if request.method == 'POST' :
        text_to_test = request.POST['text']
        scores=sia.polarity_scores(text_to_test)
        print(scores)
        '''scores_dict = {
    'sia_neg' : scores[0],
    'sia_neu' : scores[1],
    'sia_pos' : scores[2]
    }'''
        x=scores.get("compound")
        if x == 0 :
            print("You have a neutal review on the website ")
            scores='Neutral'
        elif x > 0 :
            print("Thank You for a positive review")
            scores='Positive'
        else :
            print("You have entered a negative review ")
            scores ="Negative"
        # Create an instance
        obj = db(text= text_to_test, result=scores)

# Save to the database
        obj.save()
        return render(request,'main.html',{'result' : scores})
    return render (request,'main.html')
