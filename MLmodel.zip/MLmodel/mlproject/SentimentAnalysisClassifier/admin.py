from django.contrib import admin
from .models import db

admin.site.register(db)
# Register your models here.
